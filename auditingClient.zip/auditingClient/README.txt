
Run this application 
enter into the folder 
 run this application :
  1. audit-client install
  2. audit-client start
  3.audit-client stop
  4.audit-client uninstall.